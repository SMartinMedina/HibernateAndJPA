package com.novellius.repository;

import org.springframework.data.repository.CrudRepository;

import com.novellius.domain.Inmueble;

public interface InmuebleRepository extends CrudRepository<Inmueble, Integer>{

}
