package com.novellius.repository;

import org.springframework.data.repository.CrudRepository;

import com.novellius.domain.Imagen;

public interface ImagenRepository extends CrudRepository<Imagen, Integer>{

}
